const archivos = require("./lecturaEscritura");
let arrayProfesionales = archivos.leerJson("profesionales");

//A

//B

//C

//D

//E

//F

//G 

//H 