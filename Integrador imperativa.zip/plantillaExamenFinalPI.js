// Te proveemos la siguiente plantilla que tiene dos partes:
// - Desarrollo de las consignas, donde escribirás el código que responda a los enunciados
// - Ejecución de las consignas, donde ejecutarás los métodos correspondientes mostrando por consola sus resultados
const nombre = "TU NOMBRE AQUÍ";
/*******************************/
/* Desarrollo de las consignas */
/*******************************/

// A

// B

// C

// D

// E

// F

// G


/******************************/
/* Ejecución de las consignas */
/******************************/
console.table([{ alumno: nombre }]); // NO MODIFICAR NADA DE ESTA LINEA

console.log("---------- ↧ .C. Buscar ↧ ----------");
// Ejecución aquí:
console.log("---------- ↥ ---------- ↥ ----------");

console.log("---------- ↧ .D. Filtrar ↧ ----------");
// Ejecución aquí:
console.log("---------- ↥ ------------- ↥ ----------");

console.log("---------- ↧ .E. Ordenar ↧ ----------");
// Ejecución aquí:
console.log("---------- ↥ ------------- ↥ ----------");

console.log("---------- ↧ .F. Total ↧ ----------");
// Ejecución aquí:
console.log("---------- ↥ ----------- ↥ ----------");

console.log("---------- ↧ .G. Modificar ↧ ----------");
// Ejecución aquí:
console.log("---------- ↥ --------- ↥ ----------");

